import {Component, OnDestroy} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Subscription} from 'rxjs/Subscription';
import {Subject} from 'rxjs/Subject';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.scss']
})
export class CalculatorComponent implements OnDestroy {
  result$: Observable<string>;
  leftNumberSubj = new BehaviorSubject<number>(0);
  rightNumberSubj = new BehaviorSubject<number>(null);
  calcFunctionSubj = new BehaviorSubject<CalcFunction>(null);
  execTriggerSubj = new Subject<any>();
  inputNumberSubj = new Subject<number>();

  private _subs: Array<Subscription> = [];

  constructor() {
    this.result$ = this._createResult$();
    this._subs.push(
      this._captureNumbersOnTriggers().subscribe(),
      this._captureFunctionsOnTriggers().subscribe(),
      this._emitExecOnTriggers().subscribe(),
      this._captureDeleteOnTriggers().subscribe()
    );
  }

  ngOnDestroy() {
    this._subs.forEach(sub => sub.unsubscribe());
  }

  private _captureDeleteOnTriggers = (): Observable<any> =>
    createCaptureKey$()
      .filter((e: any) => e.key === 'Backspace' || e.key === 'Delete')
      .do(() => {
        if (this.calcFunctionSubj.value) {
          this.calcFunctionSubj.next(null);
        } else if (Number.isInteger(this.rightNumberSubj.value)) {
          this.rightNumberSubj.next(removeLastDigit(this.rightNumberSubj.value));
        } else if (Number.isInteger(this.leftNumberSubj.value)) {
          this.leftNumberSubj.next(removeLastDigit(this.leftNumberSubj.value));
        }
      })

  private _emitExecOnTriggers = (): Observable<any> =>
    createCaptureKey$()
      .filter((e: any) => e.key === '=')
      .do(() => this.execTriggerSubj.next(true))

  private _createResult$ = (): Observable<string> =>
    Observable.merge(
      this._createResultAsInputString$(),
      this._createResultAsExecuted$()
    ).distinctUntilChanged()

  private _createResultAsInputString$ = (): Observable<string> =>
    Observable.combineLatest(
      this.leftNumberSubj,
      this.rightNumberSubj,
      this.calcFunctionSubj,
      (leftNumber, rightNumber, calcFunc) => toResultAsInputHtmlString(leftNumber, rightNumber, calcFunc)
    ).distinctUntilChanged()

  private _createResultAsExecuted$ = (): Observable<string> =>
    this.execTriggerSubj
      .withLatestFrom(
        Observable.combineLatest(
          this.leftNumberSubj,
          this.rightNumberSubj,
          this.calcFunctionSubj,
          (leftNumber, rightNumber, calcFunc) => ({leftNumber, rightNumber, calcFunc})
        )
      )
      .map(([_, {leftNumber, rightNumber, calcFunc}]: any) => execFunc(leftNumber, rightNumber, calcFunc).toString())
      .do(val => {
        this.leftNumberSubj.next(parseInt(val, 10));
        this.calcFunctionSubj.next(null);
        this.rightNumberSubj.next(null);
      })

  private _captureNumbersOnTriggers = (): Observable<number> =>
    Observable.merge(
      createCaptureKey$()
        .filter((e: any) => Number.isInteger(parseInt(e.key, 10)))
        .map((e: any) => parseInt(e.key, 10)),
      this.inputNumberSubj
    )
      .do((key: number) => {
        !!this.calcFunctionSubj.value ?
          this.rightNumberSubj.next(maybeAppendNumber(this.rightNumberSubj.value, key)) :
          this.leftNumberSubj.next(maybeAppendNumber(this.leftNumberSubj.value, key));
      })

  private _captureFunctionsOnTriggers = (): Observable<number> =>
    createCaptureKey$()
      .filter((e: any) => isCalcFunc(e.key))
      .map((e: any) => e.key)
      .do((key: CalcFunction) => this.calcFunctionSubj.next(key))
}

function createCaptureKey$(): Observable<any> {
  return Observable.merge(
    Observable.fromEvent(document, 'keyup'),
    Observable.fromEvent(document, 'keydown')
  ).throttleTime(300);
}

function maybeAppendNumber(oldNum: number, newDigit: number): number {
  return (
    !!oldNum ?
      parseInt(oldNum.toString() + newDigit, 10) :
      newDigit
  );
}

function removeLastDigit(number: number): number {
  const numStr = number.toString();
  return parseInt(numStr.slice(0, numStr.length - 1), 10) || null;
}

function isCalcFunc(str: string) {
  switch (str) {
    case '*':
    case '-':
    case '+':
    case '/':
      return true;
    default:
      return false;
  }
}

function calcFuncToHtml(func: CalcFunction): string {
  switch (func) {
    case '*':
      return '&times;';
    case '/':
      return '&divide;';
    default:
      return func;
  }
}

function execFunc(leftNumber: number, rightNumber: number, func: CalcFunction): number {
  switch (func) {
    case '*':
      return leftNumber * rightNumber;
    case '-':
      return leftNumber - rightNumber;
    case '+':
      return leftNumber + rightNumber;
    case '/':
      return leftNumber / rightNumber;
    default:
      throw Error('invalid calculator function');
  }
}

function toResultAsInputHtmlString(leftNumber: number, rightNumber: number, func: CalcFunction): string {
  return (Number.isInteger(leftNumber) ? leftNumber : '') + (calcFuncToHtml(func) || '') + (Number.isInteger(rightNumber) ? rightNumber : '');
}

type CalcFunction = '*' | '-' | '+' | '/';
